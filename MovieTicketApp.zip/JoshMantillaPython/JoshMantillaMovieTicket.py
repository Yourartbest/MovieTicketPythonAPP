"""
Josh Mantilla
March 14, 2025
IS218 Section 002
TicketCalculator 
"""

# Asks user for first, last name and greets them
firstName = input("\nWhat is your first name?: ");
lastName = input("What is your last name?: ");
fullName = firstName + " " + lastName;
print("\nWelcome to TicketClerk " + fullName + "!");

# Stores movie data
moviesNames = ["Man's Best Friend", "Holy Hour", "Backyarders", "Christalist", "Friday The 13th: The final Final Movie", "Escape",
 "Scream 48", "CyberPunk:Last Dance", "The Lost Chapter", "The Ugly, Ugly, and the Uglyer", "Eternia", "Walking Beside Me"];
movieGenre = ["Comedy", "Religious", "Adventure", "Action", "Horror", "Adventure",
 "Comedy/Horror", "Adventure/Action", "Adventure", "Western", "Fantasy", "Religious"];
moviePrices = [6.50, 8.00, 7.50, 5.75, 6.00, 7.25,
 6.50, 7.00, 7.00, 6.50, 6.00, 7.50]
availableSeats = [26, 32, 14, 29, 2, 0,
 13, 23, 50, 34, 26, 37]

# Makes sure that the movie data is consistant in size
if (len(moviesNames) == len(movieGenre)) & (len(movieGenre) == len(moviePrices) & len(availableSeats) == len(moviePrices)):
    movieCount = len(moviesNames);
else:
    print("Input error: Each movie must have a corresponding price and genre. Please check for equal amounts of each.");

# Creates movie holder
movies=[];

# Compiles the data for corresponding movie
for n in range(movieCount):
    movies.append([moviesNames[n], movieGenre[n], moviePrices[n], availableSeats[n]]);

# Displays the movie selection
print("Here is our movie selection:")
def movieSelection():
    for x in range(movieCount):
        print("\n"+ str(x+1) + ".) " + movies[x][0] + "\nGenre: " + movies[x][1] + "\nPrice: $" + str(movies[x][2]) + "\nAvailable Seats: " + str(movies[x][3]));
movieSelection();

# Calls movieSelection function when the user accepts the option
def seeListAgain():
    seeAgain = input("\nDo you want to see the list again? (y/n) ")
    if seeAgain == "y":
        movieSelection();

# Asks the user to choose from the movie selection 
choosenMovie = -1
while choosenMovie == -1:
    choosenMovie = int(input("\nPlease select a movie from the above listing (1-"+ str(movieCount) +"): "))
    choosenMovie = choosenMovie-1
    if choosenMovie in range(movieCount):
        if movies[choosenMovie][3] > 0:
            print("\nYou have choosen: \n" + str(choosenMovie+1)+". "+ movies[choosenMovie][0] + 
                "\nGenre: " + movies[choosenMovie][1] + "\nPrice: $" + str(movies[choosenMovie][2]))
        else:
            print("There are no more seats available for this movie. Please choose again.")
            choosenMovie=-1
            seeListAgain();
    else:
        print("Invaild selection, please try again.")
        choosenMovie=-1
        seeListAgain();

# Asks users for amount of tickets they want and checks the amount of seats to compare it
try:
    tickets = 0
    while tickets < 1: 
        tickets = int(input("\nHow many tickets would you like? "))
        if tickets <= 0:
            print("\nInvaild ticket amount, please enter an amount above 0!")
        if tickets > movies[choosenMovie][3]:
            print("There are not enough available seats for the amount of tickets you want.")
            tickets = 0
except:
    Exception("ticket error")

# Calcuates total price for the amount of tickets and asks the customer to confirm the details of their choice
try:
    price = tickets*(movies[choosenMovie][2])
    x = 0
    while x == 0:
        coupon = input("Do you have a cupoon to enter: (y/n) ") #sets coupons for the user
        percent = 0.0
        if coupon == "y":
            discount = input("Enter the coupon code: ")
            match discount:
                case "3AB":
                    percent = percent + 0.05;
                    x = 1;
                case "3BC":
                    percent = percent + 0.10;
                    x = 1;
                case "3CD":
                    percent = percent + 0.15;
                    x = 1;
                case _:
                    print("Invaild code!")
                    x=0
        else:
            x = 1;
    totalPrice=price-(round(price*percent, 2));
    print("\nPlease confirm the details below: ")
    print("\nName: " + movies[choosenMovie][0] + "\nGenre: " + movies[choosenMovie][1] + "\nPrice: $" + 
        str(price) + " ($" + str(movies[choosenMovie][2]) + "x" + str(tickets)+ ")" + "\nDiscount: -" + 
        str(round(price*percent, 2)) + "\nTotalPrice: " + str(totalPrice))
except:
    Exception("Ticket price calcutation error")

# Takes the input of the user to confirm
confirm=input("\nIs this correct? (y/n) ")
if confirm == "y":
    print("Thank you " + fullName + " for using TicketClerk! Please come again.")   
else:
    print("Sorry for the error, please try again.")
    exit();